import Home from './Home';
import { useState } from 'react';
import './App.css';

function App() {

  return (
    <div>
      <Home/>
    </div>
  )
}

export default App
